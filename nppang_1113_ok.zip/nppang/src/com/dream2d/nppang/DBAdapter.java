package com.dream2d.nppang;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


// http://blog.naver.com/PostView.nhn?blogId=javaking75&logNo=140177619818

// Singleton pattern

/**
 * �̱������� �����غ� SQLITE �̿� Ŭ����.
 * �ϸ�ũ �����ϴ� ���̺��� ���� ���ҽ��ϴ�.
 * �̿����� ���� DBAdapter.initialize �޼ҵ带 ȣ���Ŀ� Connection�� ������ ����մϴ�.
 */
public class DBAdapter {

	protected static final String DATABASE_NAME = "nppang.db";
	protected static final int DATABASE_VERSION = 1;

	private static Context mContext;
	private static SQLiteOpenHelper dbHelper;
	private static SQLiteDatabase connection;
	

	private static DBAdapter instance;

	public static void connect(Context context) {
		mContext = context;
		dbHelper = new DatabaseHelper(mContext);
		connection = dbHelper.getWritableDatabase();
	}
	
	private DBAdapter() {}
	public synchronized static DBAdapter getInstance() {
		if ( instance == null ) {
			instance = new DBAdapter();
		}
		return instance;
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {

		public DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL("CREATE TABLE "
					+ EtcClass.DB_TABLE_ACCOUNT
					+ " (" + EtcClass.ACCOUNT_PRIMARY_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, "
					+ EtcClass.ACCOUNT_BANK + " TEXT, "
					+ EtcClass.ACCOUNT_NUMBER + " TEXT, "
					+ EtcClass.ACCOUNT_OWNER + " TEXT);");
			db.execSQL("CREATE TABLE "
					+ EtcClass.DB_TABLE_LAST_SELECTED
					+ " (" + EtcClass.LAST_SELECTED_PRIMARY_KEY  + " INTEGER PRIMARY KEY AUTOINCREMENT, "
					+ EtcClass.LAST_SELECTED_NPPANG_ITEM  + " TEXT, "
					+ EtcClass.LAST_SELECTED_ACCOUNT_BANK   + " TEXT, "
					+ EtcClass.LAST_SELECTED_ACCOUNT_NUMBER   + " TEXT, "
					+ EtcClass.LAST_SELECTED_ACCOUNT_OWNER  + " TEXT);");		
			
			db.execSQL("CREATE TABLE "
					+ EtcClass.DB_TABLE_NPPANG_ITEM
					+ " (" + EtcClass.NPPANG_ITEM_PRIMARY_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, "					
					+ EtcClass.NPPANG_ITEM + " TEXT);");
			
			db.execSQL("CREATE TABLE "
					+ EtcClass.DB_TABLE_SENT_NPPANG_LIST
					+ " (" + EtcClass.SENT_NPPANG_LIST_PRIMARY_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, "
					+ EtcClass.SENT_NPPANG_LIST_DATE + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_N + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_MONEY + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_ACCOUNT_NUMBER + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_ACCOUNT_OWNER + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_BANK + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_NPPANG_ITEM + " TEXT, "
					+ EtcClass.SENT_NPPANG_LIST_MESSAGE + " TEXT);");
			
			
			inputInitDatebaseValue(db);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// DB �� ������Ʈ�ɶ� �����
			db.execSQL("DROP TABLE IF EXISTS " + EtcClass.DB_TABLE_ACCOUNT);
			db.execSQL("DROP TABLE IF EXISTS " + EtcClass.DB_TABLE_LAST_SELECTED);
			db.execSQL("DROP TABLE IF EXISTS " + EtcClass.DB_TABLE_SENT_NPPANG_LIST);
			db.execSQL("DROP TABLE IF EXISTS " + EtcClass.DB_TABLE_NPPANG_ITEM);
			onCreate(db);
		}
		
		public void inputInitDatebaseValue(SQLiteDatabase connection){
			ContentValues contentvalue = new ContentValues();
			
			// ���������� ������ ���� invalid ������ �ʱ�ȭ�Ѵ�.
			contentvalue.put(EtcClass.LAST_SELECTED_NPPANG_ITEM , EtcClass.INVALID_VALUE);
			contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_BANK , EtcClass.INVALID_VALUE);		
			contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER  , EtcClass.INVALID_VALUE);
			contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_OWNER  , EtcClass.INVALID_VALUE);
			if(connection.insert(EtcClass.DB_TABLE_LAST_SELECTED , null, contentvalue) == 0){
				Toast.makeText(mContext, "DB �Է� ����", Toast.LENGTH_SHORT).show();
			}
			
			// �⺻���� ��Ÿ�� N�� Item �� �Է��Ѵ�.
			String[] mNppangItemList= mContext.getResources().getStringArray(R.array.basic_nppang_item);
			for(int i=0; i<mNppangItemList.length; i++){
				contentvalue = new ContentValues();
				contentvalue.put(EtcClass.NPPANG_ITEM, mNppangItemList[i]);
				if(connection.insert(EtcClass.DB_TABLE_NPPANG_ITEM, null, contentvalue) == 0){
					Toast.makeText(mContext, "DB �Է� ���� in appendNppangItem", Toast.LENGTH_SHORT).show();
				}					
			}
		}
	}
	
	public static ArrayList<String> getNppangItemList() {	
		ArrayList<String> returnValue = new ArrayList<String>();
		Cursor cursor = connection.rawQuery("SELECT * FROM " + EtcClass.DB_TABLE_NPPANG_ITEM, null);
		while(cursor.moveToNext()){			
			returnValue.add(cursor.getString(cursor.getColumnIndex(EtcClass.NPPANG_ITEM)).toString());			
		}		
		cursor.close();
		return returnValue;
	}

	public static ArrayList<Map<String, String>> getAccountList() {	
		ArrayList<Map<String, String>> returnValue = new ArrayList<Map<String, String>>();
		Cursor cursor = connection.rawQuery("SELECT * FROM " + EtcClass.DB_TABLE_ACCOUNT, null);
		while(cursor.moveToNext()){
			Map<String, String> accountInfomation = new HashMap<String, String>();
			accountInfomation.put(EtcClass.ACCOUNT_PRIMARY_KEY, cursor.getString(cursor.getColumnIndex(EtcClass.ACCOUNT_PRIMARY_KEY)).toString());
			accountInfomation.put(EtcClass.ACCOUNT_BANK, cursor.getString(cursor.getColumnIndex(EtcClass.ACCOUNT_BANK)).toString());
			accountInfomation.put(EtcClass.ACCOUNT_NUMBER, cursor.getString(cursor.getColumnIndex(EtcClass.ACCOUNT_NUMBER)).toString());
			accountInfomation.put(EtcClass.ACCOUNT_OWNER, cursor.getString(cursor.getColumnIndex(EtcClass.ACCOUNT_OWNER)).toString());
			returnValue.add(accountInfomation);
		}		
		cursor.close();
		return returnValue;
	}
	
	public static Map<String, String> getLastSelected() {	
		Map<String, String> returnValue = new HashMap<String, String>();
		Cursor cursor = connection.rawQuery("SELECT * FROM " + EtcClass.DB_TABLE_LAST_SELECTED, null);
		while(cursor.moveToNext()){			
			returnValue.put(EtcClass.LAST_SELECTED_PRIMARY_KEY , cursor.getString(cursor.getColumnIndex(EtcClass.LAST_SELECTED_PRIMARY_KEY )).toString());
			returnValue.put(EtcClass.LAST_SELECTED_NPPANG_ITEM , cursor.getString(cursor.getColumnIndex(EtcClass.LAST_SELECTED_NPPANG_ITEM )).toString());
			returnValue.put(EtcClass.LAST_SELECTED_ACCOUNT_BANK , cursor.getString(cursor.getColumnIndex(EtcClass.LAST_SELECTED_ACCOUNT_BANK )).toString());
			returnValue.put(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER , cursor.getString(cursor.getColumnIndex(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER )).toString());
			returnValue.put(EtcClass.LAST_SELECTED_ACCOUNT_OWNER , cursor.getString(cursor.getColumnIndex(EtcClass.LAST_SELECTED_ACCOUNT_OWNER )).toString());			
		}		
		cursor.close();
		return returnValue;
	}
	
	public static void setLastSelected(Map<String, String> lastSelected) {	
		ContentValues contentvalue = new ContentValues();
		contentvalue.put(EtcClass.LAST_SELECTED_NPPANG_ITEM, lastSelected.get(EtcClass.LAST_SELECTED_NPPANG_ITEM));
		contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_BANK , lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_BANK ));
		contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER , lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER ));
		contentvalue.put(EtcClass.LAST_SELECTED_ACCOUNT_OWNER , lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_OWNER ));
		if(connection.update(EtcClass.DB_TABLE_LAST_SELECTED , contentvalue, EtcClass.LAST_SELECTED_PRIMARY_KEY + "=1", null) == 0){
			Toast.makeText(mContext, "DB �Է� ����", Toast.LENGTH_SHORT).show();
		}
	}
	
	public static void deleteAccount(int accountId){
		connection.execSQL("DELETE FROM " + EtcClass.DB_TABLE_ACCOUNT + " WHERE " + EtcClass.ACCOUNT_PRIMARY_KEY + "=" + accountId + ";");		
	}
	
	public static void appendNppangItem(String item){
		ContentValues contentvalue = new ContentValues();
		contentvalue.put(EtcClass.NPPANG_ITEM, item);
		if(connection.insert(EtcClass.DB_TABLE_NPPANG_ITEM, null, contentvalue) == 0){
			Toast.makeText(mContext, "DB �Է� ���� in appendNppangItem", Toast.LENGTH_SHORT).show();
		}
	}
	
	public static void appendAccount(String bank, String number, String owner){
		ContentValues contentvalue = new ContentValues();
		contentvalue.put(EtcClass.ACCOUNT_BANK, bank);
		contentvalue.put(EtcClass.ACCOUNT_NUMBER, number);
		contentvalue.put(EtcClass.ACCOUNT_OWNER, owner);
		if(connection.insert(EtcClass.DB_TABLE_ACCOUNT, null, contentvalue) == 0){					
			Toast.makeText(mContext, "DB �Է� ����", Toast.LENGTH_SHORT).show();
		}
	}
	
	
	public void close() {
		try {
			connection.close();
			dbHelper.close();
		} catch (Exception e) {}
	}
}