package com.dream2d.nppang;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;


import com.dream2d.nppang.R;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnLongClickListener;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.LinearLayout.LayoutParams;

public class SelectNppangItem extends Activity  {
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;
	
	
	

	public static Context mContext;
	ArrayAdapter<String> adapter;
	ArrayList<String> alist;
	
	ListView mListViewNppangItemList;
	Button mButtonAppendNppangItem;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.select_nppang_item);

		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();
		mContext = this;
		mListViewNppangItemList = (ListView) findViewById(R.id.list_view_nppang_item_list);
		mButtonAppendNppangItem = (Button) findViewById(R.id.button_append_nppang_item);
		
		mButtonAppendNppangItem.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent(SelectNppangItem.this, AppendNppangItem.class);
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_APPEND_NPPANG_ITEM);
			}
		});
		
		// ��ü�� �����մϴ�
		alist = new ArrayList<String>();
		adapter = new ArrayAdapter(mContext, R.layout.custom_simple_list_item_single_choice, alist);
		mListViewNppangItemList.setAdapter(adapter);
		mListViewNppangItemList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		
		updateAccountList();
		
		String initSelectItem = getIntent().getExtras().getString(EtcClass.NPPANG_ITEM);
		for(int i=0; i<alist.size(); i++){
			if(alist.get(i).equals(initSelectItem)){
				mListViewNppangItemList.setItemChecked(i, true);
			}
			
		}
			
		

		// ����Ʈ�信 ������ Ŭ�� ������ ����
		mListViewNppangItemList.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {				
				Intent intent = new Intent();										
				Bundle extra = new Bundle();										
				extra.putString(EtcClass.NPPANG_ITEM, mListViewNppangItemList.getItemAtPosition(position).toString());
				intent.putExtras(extra);
				
				SelectNppangItem.this.setResult(RESULT_OK, intent);
				SelectNppangItem.this.finish();
			}
		});

		// ����Ʈ�信 ������ ��Ŭ�� ������ ����
		mListViewNppangItemList.setOnItemLongClickListener(new OnItemLongClickListener(){
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View v, final int position, long id) {
				AlertDialog.Builder alertDlg = new AlertDialog.Builder(SelectNppangItem.this);
				alertDlg.setPositiveButton( R.string.yes, new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick( DialogInterface dialog, int which ) {
						/*
						DBAdapter.deleteAccount(Integer.parseInt(mAccountInfomation.get(position).get(EtcClass.ACCOUNT_ID)));
						Toast.makeText(getBaseContext(), "���� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();						
						alist.remove(position);
						updateAccountList();
						recreate();
						*/
						
					}
				});

				alertDlg.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick( DialogInterface dialog, int which ) {
						dialog.dismiss();  // AlertDialog�� �ݴ´�.						
					}
				});	        
				alertDlg.setMessage( "�ش� ���¸� ���� �Ͻðڽ��ϱ�?");
				alertDlg.show();
				return false;
			}

		});
		getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_APPEND_NPPANG_ITEM:
			if(resultCode == RESULT_OK){				
				updateAccountList();				
			}
		}
	}
	public void updateAccountList(){
		ArrayList<String> mNppangList = DBAdapter.getNppangItemList();				
		alist.clear();
		for(int i=0; i<mNppangList.size(); i++){
			alist.add(mNppangList.get(i));
		}
		// refresh �Ѵ�.
		adapter.notifyDataSetChanged();
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}



}