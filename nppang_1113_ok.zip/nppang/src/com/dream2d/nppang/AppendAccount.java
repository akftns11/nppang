package com.dream2d.nppang;

import com.dream2d.nppang.R;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class AppendAccount extends Activity {
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;
	
	Button mButtonAppendAccountOk;
	Button mButtonAppendAccountCancel;
	Button mButtonSelectAccountBank;
	EditText mEditTextAccountOwnerName;
	EditText mEditTextAccountNumber;
	//EditText mEditTextAccountBank;
	
	SQLiteDatabase myDB;
	ContentValues contentvalue;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.append_account);
		
		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();
		
		mButtonAppendAccountOk = (Button) findViewById(R.id.button_append_account_ok);
		mButtonAppendAccountCancel = (Button) findViewById(R.id.button_append_account_cancel);
		mButtonSelectAccountBank = (Button) findViewById(R.id.button_select_account_bank);
		mEditTextAccountOwnerName = (EditText) findViewById(R.id.edit_text_account_owner);
		mEditTextAccountNumber = (EditText) findViewById(R.id.edit_text_account_number);
		
		
			
		
		mButtonAppendAccountOk.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				DBAdapter.appendAccount(mButtonSelectAccountBank.getText().toString(), mEditTextAccountNumber.getText().toString(), mEditTextAccountOwnerName.getText().toString());
				Toast.makeText(AppendAccount.this, "�߰� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
				
				AppendAccount.this.setResult(RESULT_OK);
				AppendAccount.this.finish();
			}
		});
		mButtonAppendAccountCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				AppendAccount.this.finish();
			}
		});
		
		mButtonSelectAccountBank.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				Intent intent = new Intent(AppendAccount.this, SelectBank.class);				
				intent.putExtra(EtcClass.ACCOUNT_BANK, (String)mButtonSelectAccountBank.getText());
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_BANK);
			}
		});
		
		;

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){		
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_BANK :
			if(resultCode == RESULT_OK){
				mButtonSelectAccountBank.setText(data.getExtras().getString(EtcClass.ACCOUNT_BANK));				
			}
			break;
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}
	
	
}
