package com.dream2d.nppang;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;


import com.dream2d.nppang.R;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnLongClickListener;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.LinearLayout.LayoutParams;

public class LoadAccount extends Activity  {
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;
	
	ListView mListViewAccountList;
	

	public static Context mContext;
	ArrayAdapter<String> adapter;
	ArrayList<String> alist;
	
	ArrayList<Map<String, String>> mAccountInfomation;
	Button mButtonAppendAccount;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.load_account);

		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();
		mContext = this;
		mListViewAccountList = (ListView) findViewById(R.id.list_view_account_list);
		mButtonAppendAccount = (Button) findViewById(R.id.button_append_account);
		
		mButtonAppendAccount.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent(LoadAccount.this, AppendAccount.class);
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_APPEND_ACCOUNT);
			}
		});
		
		// ��ü�� �����մϴ�
		alist = new ArrayList<String>();
		adapter = new ArrayAdapter(mContext, R.layout.custom_simple_list_item_single_choice, alist);
		mListViewAccountList.setAdapter(adapter);
		mListViewAccountList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		
		updateAccountList();
		

		// ����Ʈ�信 ������ Ŭ�� ������ ����
		mListViewAccountList.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
				//String str = (String)adapter.getItem(position);
				//Toast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();
				
				Intent intent = new Intent();										
				Bundle extra = new Bundle();										
				extra.putString(EtcClass.ACCOUNT_BANK, mAccountInfomation.get(position).get(EtcClass.ACCOUNT_BANK));
				intent.putExtras(extra);
				extra = new Bundle();									
				extra.putString(EtcClass.ACCOUNT_NUMBER, mAccountInfomation.get(position).get(EtcClass.ACCOUNT_NUMBER));
				intent.putExtras(extra);
				extra = new Bundle();									
				extra.putString(EtcClass.ACCOUNT_OWNER, mAccountInfomation.get(position).get(EtcClass.ACCOUNT_OWNER));
				intent.putExtras(extra);
				
				LoadAccount.this.setResult(RESULT_OK, intent);
				LoadAccount.this.finish();
			}
		});

		// ����Ʈ�信 ������ ��Ŭ�� ������ ����
		mListViewAccountList.setOnItemLongClickListener(new OnItemLongClickListener(){
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View v, final int position, long id) {
				AlertDialog.Builder alertDlg = new AlertDialog.Builder(LoadAccount.this);
				alertDlg.setPositiveButton( R.string.yes, new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick( DialogInterface dialog, int which ) {
						DBAdapter.deleteAccount(Integer.parseInt(mAccountInfomation.get(position).get(EtcClass.ACCOUNT_PRIMARY_KEY)));
						Toast.makeText(getBaseContext(), "���� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();						
						alist.remove(position);
						updateAccountList();
						recreate();
						
					}
				});

				alertDlg.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick( DialogInterface dialog, int which ) {
						dialog.dismiss();  // AlertDialog�� �ݴ´�.						
					}
				});	        
				alertDlg.setMessage( "�ش� ���¸� ���� �Ͻðڽ��ϱ�?");
				alertDlg.show();
				return false;
			}

		});
		getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_APPEND_ACCOUNT :
			if(resultCode == RESULT_OK){				
				updateAccountList();				
			}
		}
	}
	public void updateAccountList(){
		mAccountInfomation = DBAdapter.getAccountList();		
		alist.clear();
		for(int i=0; i<mAccountInfomation.size(); i++){
			alist.add("���� : " + mAccountInfomation.get(i).get(EtcClass.ACCOUNT_BANK) + System.getProperty("line.separator")
					+ "���¹�ȣ : " + mAccountInfomation.get(i).get(EtcClass.ACCOUNT_NUMBER) + System.getProperty("line.separator")
					+ "������ : " + mAccountInfomation.get(i).get(EtcClass.ACCOUNT_OWNER) + System.getProperty("line.separator"));
		}
		// refresh �Ѵ�.
		adapter.notifyDataSetChanged();
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}



}