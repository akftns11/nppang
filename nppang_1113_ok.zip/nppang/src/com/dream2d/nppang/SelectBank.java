package com.dream2d.nppang;


import java.util.ArrayList;

import java.util.Calendar;


import com.dream2d.nppang.R;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout.LayoutParams;

public class SelectBank extends Activity  {
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;


	// ����Ʈ�� ����
	ListView mListview;
	TextView mTitle;
	// �����͸� ������ Adapter
	ArrayAdapter<String> adapter;
	// �����͸� ���� �ڷᱸ��
	ArrayList<String> alist;	
	


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.custom_spinner);

		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();
		// ������ ����Ʈ�信 ����� �����俬��
		mListview = (ListView) findViewById(R.id.list_view_contents);
		mTitle = (TextView) findViewById(R.id.text_view_title);
		mTitle.setText(R.string.select_bank);

		// ��ü�� �����մϴ�
		alist = new ArrayList<String>();

		// �����͸� �ޱ����� �����;���� ��ü ����
		adapter = new ArrayAdapter(SelectBank.this, R.layout.custom_simple_list_item_single_choice, alist);		


		// ����Ʈ�信 ����� ����
		mListview.setAdapter(adapter);
		mListview.setChoiceMode(ListView.CHOICE_MODE_SINGLE);


		String initSelectBank = getIntent().getExtras().getString(EtcClass.ACCOUNT_BANK);
		
		
		String[] mBankList= getResources().getStringArray(R.array.bank_list);
		
		for(int i=0; i<mBankList.length; i++){
			alist.add(mBankList[i]);
			
			if(mBankList[i].equals(initSelectBank)){
				mListview.setItemChecked(i, true);
			}
		}


		// ����
		getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));



		// ����Ʈ�信 ������ Ŭ�� ������ ����
		mListview.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
				Intent intent = new Intent(); 
				Bundle extra = new Bundle();									
				extra.putString(EtcClass.ACCOUNT_BANK, (String)adapter.getItem(position));
				intent.putExtras(extra);
				SelectBank.this.setResult(RESULT_OK, intent);
				SelectBank.this.finish();
			}
		});


	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {			
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}



}