




// pager http://arabiannight.tistory.com/53
// EditText, ViewText �Ӽ��� http://androiddeveloper.tistory.com/42

package com.dream2d.nppang;



import java.util.ArrayList;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;



import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Fragment;


import android.app.FragmentManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.TabSpec;
import android.widget.Toast;
import com.dream2d.nppang.R;
import com.fsn.cauly.CaulyAdInfo;
import com.fsn.cauly.CaulyAdInfoBuilder;
import com.fsn.cauly.CaulyInterstitialAd;
import com.fsn.cauly.CaulyInterstitialAdListener;


public class MainActivity extends Activity implements CaulyInterstitialAdListener{
	private ViewPager mPager;
	private ImageButton mImageButtonSendNppang;
	private ImageButton mImageButtonSendedList;
	private ImageButton mImageButtonAboutUs;   
	LoadNppangTotalMoney mLoadNppangTotalMoney;
	SelectNppangPersonCount mNppangPersionCount;
	EditText mEditTextTotalNppangMoney;
	EditText mEditTextAccountNumber;
	EditText mEditTextAccountOwner;
	EditText mEditTextNppangSendMessage;
	Button mButtonNppangPersonCount;
	Button mButtonDatePicker;
	Button mButtonSelectBank;
	Button mButtonLoadAccount;
	Button mButtonSendNppang;
	Button mButtonSelectNppangItem;
	TextView mTextViewNppangMoney;
	TextWatcher mTextWatcher;


	View mViewSendNppang;
	View mViewSentList;
	View mViewAboutUs;

	Calendar mCalendarToday = Calendar.getInstance();

	// Back�� ���°��� �����ϱ� ���� ����
	boolean mCloaeApplicationFlag = false;
	// ���� �ð� �� ���°��� �ʱ�ȭ�ϱ� ���� �ڵ鷯
	Handler mCloaeApplicationHandler = new Handler() {
		public void handleMessage(Message msg) {
			mCloaeApplicationFlag = false;
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		startActivity(new Intent(MainActivity.this, Intro.class));
		setContentView(R.layout.activity_main);
		setMainLayout();

		DBAdapter.connect(this);

		mPager = (ViewPager)findViewById(R.id.pager);
		mPager.setAdapter(new PagerAdapterClass(getApplicationContext()));

		mImageButtonSendNppang.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				setCurrentInflateItem(EtcClass.SEND_NPPANG);				
			}
		});

		mImageButtonSendedList.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				setCurrentInflateItem(EtcClass.SENDED_LIST);				
			}
		});

		mImageButtonAboutUs.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				setCurrentInflateItem(EtcClass.ABOUT_US);				
			}
		});       

		mPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageScrollStateChanged(int arg0) {
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}
			@Override
			public void onPageSelected(int position) {				
				// ȭ���� �ٲ�� ��ܿ� �ִ� ��ư�� �׸��� �ٲ��ش� (���� �������� ��ư�� ��ġ ��Ų��.)
				if(position == EtcClass.SEND_NPPANG){
					mImageButtonSendNppang.setImageResource(R.drawable.button_send_nppang_enable);
					mImageButtonSendedList.setImageResource(R.drawable.button_sended_list_disable);
					mImageButtonAboutUs.setImageResource(R.drawable.button_about_us_disable);					
				}
				else if(position == EtcClass.SENDED_LIST){
					mImageButtonSendNppang.setImageResource(R.drawable.button_send_nppang_disable);
					mImageButtonSendedList.setImageResource(R.drawable.button_sended_list_enable);
					mImageButtonAboutUs.setImageResource(R.drawable.button_about_us_disable);
				}
				else if(position == EtcClass.ABOUT_US){
					mImageButtonSendNppang.setImageResource(R.drawable.button_send_nppang_disable);
					mImageButtonSendedList.setImageResource(R.drawable.button_sended_list_disable);
					mImageButtonAboutUs.setImageResource(R.drawable.button_about_us_enable);
				}
			}        	
		});
		setCurrentInflateItem(EtcClass.SENDED_LIST);
		setCurrentInflateItem(EtcClass.SEND_NPPANG);

		mTextWatcher = new TextWatcher()
		{
			@Override
			public void afterTextChanged(Editable s) {
				//�ؽ�Ʈ ���� �� �߻��� �̺�Ʈ�� �ۼ�.
			}		 
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after)
			{
				//�ؽ�Ʈ�� ���̰� ����Ǿ��� ��� �߻��� �̺�Ʈ�� �ۼ�.
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count)
			{
				UpdateSendMessage();

			}
		};

		setSendNppangLayout();
		setSentListLayout();
		setAboutUsLayout();
		
        deleteShortcutAtLuncher();
    	addShortcutToLuncher();
            
        
		
	}

	private void setSendNppangLayout(){		
		// layout �� �����´�.
		mViewSendNppang = (View) getLayoutInflater().inflate(R.layout.send_nppang, null);

		// Button �� �������ش�.	mOnClickListenerSendNppang �����θ� ���� �ȴ�.
		mViewSendNppang.findViewById(R.id.button_load_from_sms).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_nppang_person_count).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_date_picker).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_select_bank).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_load_account).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_send_nppang).setOnClickListener(mOnClickListenerSendNppang);
		mViewSendNppang.findViewById(R.id.button_select_nppang_item).setOnClickListener(mOnClickListenerSendNppang);

		// �̺�Ʈ ó���� ���� xml�� ����� item �� java �ڵ�� �������ش�.
		mEditTextTotalNppangMoney = (EditText) mViewSendNppang.findViewById(R.id.edit_text_total_nppang_money);
		mEditTextAccountNumber = (EditText) mViewSendNppang.findViewById(R.id.edit_text_account_number);
		mEditTextAccountOwner = (EditText) mViewSendNppang.findViewById(R.id.edit_text_account_owner);    			
		mEditTextNppangSendMessage = (EditText) mViewSendNppang.findViewById(R.id.edit_text_nppang_send_message);
		mButtonNppangPersonCount = (Button) mViewSendNppang.findViewById(R.id.button_nppang_person_count);
		mButtonDatePicker = (Button) mViewSendNppang.findViewById(R.id.button_date_picker);
		mButtonSelectBank = (Button) mViewSendNppang.findViewById(R.id.button_select_bank);
		mButtonLoadAccount = (Button) mViewSendNppang.findViewById(R.id.button_load_account);
		mButtonSendNppang = (Button) mViewSendNppang.findViewById(R.id.button_send_nppang);
		mButtonSelectNppangItem = (Button) mViewSendNppang.findViewById(R.id.button_select_nppang_item);
		mTextViewNppangMoney = (TextView) mViewSendNppang.findViewById(R.id.text_view_nppang_money);

		// N�� �޽����� �ڵ� Update �� ���� edit text�� watcher�� �������ش�.
		mEditTextTotalNppangMoney.addTextChangedListener(mTextWatcher);			
		mEditTextAccountNumber.addTextChangedListener(mTextWatcher);
		mEditTextAccountOwner.addTextChangedListener(mTextWatcher);

		// ���� ��¥�� �ʱ�ȭ ���ش�.		
		mButtonDatePicker.setText("" + mCalendarToday.get(Calendar.YEAR)
				+ "�� " + (mCalendarToday.get(Calendar.MONTH)+1) + "�� " + mCalendarToday.get(Calendar.DAY_OF_MONTH) + "��");

		// ���������� ������ ���� �����´�.
		Map<String, String> lastSelected = DBAdapter.getLastSelected();
		if(!lastSelected.get(EtcClass.LAST_SELECTED_NPPANG_ITEM).equals(EtcClass.INVALID_VALUE)){
			mButtonSelectNppangItem.setText(lastSelected.get(EtcClass.LAST_SELECTED_NPPANG_ITEM));
		}
		if(!lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_BANK).equals(EtcClass.INVALID_VALUE)){
			mButtonSelectBank.setText(lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_BANK ));
		}
		if(!lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER ).equals(EtcClass.INVALID_VALUE)){
			mEditTextAccountNumber.setText(lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER  ));
		}
		if(!lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_OWNER  ).equals(EtcClass.INVALID_VALUE)){
			mEditTextAccountOwner.setText(lastSelected.get(EtcClass.LAST_SELECTED_ACCOUNT_OWNER   ));
		}
	}
	private void setSentListLayout(){		
		mViewSentList = (View) getLayoutInflater().inflate(R.layout.sent_list, null);		
	}
	private void setAboutUsLayout(){		
		mViewAboutUs = (View) getLayoutInflater().inflate(R.layout.about_us, null);		
	}

	// N�� �����⿡ Layout�� ��ư Ŭ���� ���� ���� ����
	private OnClickListener mOnClickListenerSendNppang = new OnClickListener() {		//Ŭ�� �̺�Ʈ ��ü
		public void onClick(View v) {
			Intent intent;
			switch(v.getId()){
			case R.id.button_load_from_sms	:
				intent = new Intent(MainActivity.this, LoadNppangTotalMoney.class);				
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_LOAD_NPPANG_TOTAL_MONEY);
				break;
			case R.id.button_nppang_person_count	:
				intent = new Intent(MainActivity.this, SelectNppangPersonCount.class);				
				intent.putExtra(EtcClass.NPPANG_PERSON_COUNT, Integer.parseInt((String)mButtonNppangPersonCount.getText()));
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_NPPANG_PERSON_COUNT);	

				break;

			case R.id.button_date_picker	:				
				intent = new Intent(MainActivity.this, CustomDatePicker.class);				
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_DATE_PICKER);

				break;
			case R.id.button_select_bank	:	
				intent = new Intent(MainActivity.this, SelectBank.class);				
				intent.putExtra(EtcClass.ACCOUNT_BANK, (String)mButtonSelectBank.getText());
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_BANK);				
				break;

			case R.id.button_load_account	:				
				intent = new Intent(MainActivity.this, LoadAccount.class);				
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_LOAD_ACCOUNT);
				break;
			case R.id.button_send_nppang	:
				// ���õǾ� �ִ� ���� ������ ������ DB �� �����Ѵ�.
				// App ����� �ڵ� �ʱⰪ ������ ����
				Map<String, String> lastSelect = new HashMap<String, String>();
				lastSelect.put(EtcClass.LAST_SELECTED_NPPANG_ITEM, mButtonSelectNppangItem.getText().toString());
				lastSelect.put(EtcClass.LAST_SELECTED_ACCOUNT_BANK , mButtonSelectBank.getText().toString());
				lastSelect.put(EtcClass.LAST_SELECTED_ACCOUNT_NUMBER , mEditTextAccountNumber.getText().toString());
				lastSelect.put(EtcClass.LAST_SELECTED_ACCOUNT_OWNER , mEditTextAccountOwner.getText().toString());
				DBAdapter.setLastSelected(lastSelect);

				
				// CaulyAdInfo ����
				// ��� ������ �����ϰ� ���� ��û�� ������ �� �ִ�.
				// ���� ���� ����
				String APP_CODE = "7jpEiQ0c";
				CaulyAdInfo interstitialAdInfo = new CaulyAdInfoBuilder(APP_CODE).build();
				CaulyInterstitialAd interstitialAd = new CaulyInterstitialAd();
				interstitialAd.setAdInfo(interstitialAdInfo);
				interstitialAd.setInterstialAdListener( MainActivity.this);
				// ���� ��û. ���� ������ CaulyInterstitialAdListener�� onReceiveInterstitialAd���� ó���Ѵ�.
				interstitialAd.requestInterstitialAd( MainActivity.this);		
				
				// N���� ������.
				intent = new Intent(Intent.ACTION_SEND);
				intent.setType("text/plain");
				intent.putExtra(Intent.EXTRA_TEXT, mEditTextNppangSendMessage.getText().toString());
				startActivity(Intent.createChooser(intent,"N �� ������"));				
				break;
			case R.id.button_select_nppang_item	:
				intent = new Intent(MainActivity.this, SelectNppangItem.class);				
				intent.putExtra(EtcClass.NPPANG_ITEM, (String)mButtonSelectNppangItem.getText());
				startActivityForResult(intent, EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_NPPANG_ITEM);	
				break;
			}

		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_DATE_PICKER :
			if(resultCode == RESULT_OK){
				mButtonDatePicker.setText("" + data.getExtras().getInt(EtcClass.YEAR)
						+ "�� " + data.getExtras().getInt(EtcClass.MONTH) + "�� " + data.getExtras().getInt(EtcClass.DAY) + "��");
				UpdateSendMessage();
			}
			break;
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_BANK :
			if(resultCode == RESULT_OK){
				mButtonSelectBank.setText(data.getExtras().getString(EtcClass.ACCOUNT_BANK));
				UpdateSendMessage();
			}
			break;
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_NPPANG_PERSON_COUNT :
			if(resultCode == RESULT_OK){
				mButtonNppangPersonCount.setText(""+data.getExtras().getInt(EtcClass.NPPANG_PERSON_COUNT));
				UpdateSendMessage();
			}		
			break;
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_LOAD_NPPANG_TOTAL_MONEY :
			if(resultCode == RESULT_OK){
				mEditTextTotalNppangMoney.setText(""+data.getExtras().getInt(EtcClass.NPPANG_TOTAL_MONEY));
				UpdateSendMessage();
			}
			break;
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_LOAD_ACCOUNT :
			if(resultCode == RESULT_OK){
				mButtonSelectBank.setText(data.getExtras().getString(EtcClass.ACCOUNT_BANK));
				mEditTextAccountNumber.setText(data.getExtras().getString(EtcClass.ACCOUNT_NUMBER));
				mEditTextAccountOwner.setText(data.getExtras().getString(EtcClass.ACCOUNT_OWNER));
				UpdateSendMessage();
			}
			break;
		case EtcClass.ACTIVITY_REQUEST_CODE_FOR_SELECT_NPPANG_ITEM :
			if(resultCode == RESULT_OK){
				mButtonSelectNppangItem.setText(data.getExtras().getString(EtcClass.NPPANG_ITEM));
				UpdateSendMessage();
			}
			break;
		}
	}

	private void setCurrentInflateItem(int type){
		if(type==0){
			mPager.setCurrentItem(EtcClass.SEND_NPPANG);
		}else if(type==1){
			mPager.setCurrentItem(EtcClass.SENDED_LIST);
		}else{
			mPager.setCurrentItem(EtcClass.ABOUT_US);
		}
	} 

	private void setMainLayout(){
		mImageButtonSendNppang = (ImageButton) findViewById(R.id.image_button_send_nppang);
		mImageButtonSendedList = (ImageButton) findViewById(R.id.image_button_sended_list);
		mImageButtonAboutUs = (ImageButton) findViewById(R.id.image_button_about_us);
	}

	public void UpdateSendMessage(){
		String mSetMessage;
		mSetMessage ="[N��] "  + mButtonDatePicker.getText().toString() + System.getProperty("line.separator")				
				+ "�Ѿ� : " + mEditTextTotalNppangMoney.getText() + "��" + System.getProperty("line.separator") 
				+ "N : " + mButtonNppangPersonCount.getText().toString() + "��" + System.getProperty("line.separator") 
				+ "N�� : ";				
		try{			
			mTextViewNppangMoney.setText(""+Integer.parseInt(mEditTextTotalNppangMoney.getText().toString())/Integer.parseInt(mButtonNppangPersonCount.getText().toString()));
		}catch (Exception e) {
			mTextViewNppangMoney.setText("");
		}
		mSetMessage += mTextViewNppangMoney.getText().toString() + "��"+ System.getProperty("line.separator");


		mSetMessage += mButtonSelectBank.getText() + " " + mEditTextAccountNumber.getText() + " " + mEditTextAccountOwner.getText() + "(��)�� �Ա� ��Ź�帳�ϴ�."  + System.getProperty("line.separator") ;
		mSetMessage += "���� : " + mButtonSelectNppangItem.getText().toString();
		mEditTextNppangSendMessage.setText(mSetMessage);

	}

	private class PagerAdapterClass extends PagerAdapter{
		private LayoutInflater mInflater;    

		public PagerAdapterClass(Context c){
			super();
			mInflater = LayoutInflater.from(c);
		}

		@Override
		public int getCount() {
			return EtcClass.PAGE_COUNT;
		}       

		@Override
		public Object instantiateItem(View pager, int position) {
			View v = null;            
			if(position==EtcClass.SEND_NPPANG){
				//v = mInflater.inflate(R.layout.send_nppang, null);
				v = mViewSendNppang;			}
			else if(position==EtcClass.SENDED_LIST){
				v = mViewSentList;             
			}
			else if(position==EtcClass.ABOUT_US){
				v = mViewAboutUs;
			}

			((ViewPager)pager).addView(v, 0);

			return v; 
		}



		@Override
		public void destroyItem(View pager, int position, Object view) {    
			((ViewPager)pager).removeView((View)view);
		}

		@Override
		public boolean isViewFromObject(View pager, Object obj) {
			return pager == obj; 
		}

		@Override public void restoreState(Parcelable arg0, ClassLoader arg1) {}
		@Override public Parcelable saveState() { return null; }
		@Override public void startUpdate(View arg0) {}
		@Override public void finishUpdate(View arg0) {}
	}


	// Back Ű�� ��ġ�Ǹ� ȣ��Ǵ� �޼ҵ�
	// Back �ι� ���� App ���Ḧ ����
	@Override
	public void onBackPressed () 
	{   // mCloaeApplicationFlag �� false �̸� ù��°�� Ű�� ���� ���̴�.
		if(mCloaeApplicationFlag == false) { // Back Ű�� ù��°�� ���� ���
			// �ȳ� �޼����� �佺Ʈ�� ����Ѵ�.
			Toast.makeText(this, "���Ű�� ���� �ѹ� �� �����ø� ����˴ϴ�.", Toast.LENGTH_LONG).show();
			// ���°� ����
			mCloaeApplicationFlag = true;
			// �ڵ鷯�� �̿��Ͽ� 3�� �Ŀ� 0�� �޼����� �����ϵ��� �����Ѵ�.
			mCloaeApplicationHandler.sendEmptyMessageDelayed(0, EtcClass.BACK_DELEAY_TIME_FOR_FINISH_ACTIVITY);
		} else { // Back Ű�� 3�� ���� ���޾Ƽ� �ι� ���� ���

			// ��Ƽ��Ƽ�� �����ϴ� ���� Ŭ������ onBackPressed �޼ҵ带 ȣ���Ѵ�.
			super.onBackPressed();
		}
	}

	// ��ó�� Shortcut(�ٷΰ���) �� �����Ѵ�.
	public void addShortcutToLuncher(){
		Intent shortcutIntent = new Intent(Intent.ACTION_MAIN);
		shortcutIntent.setClassName(this, this.getClass().getName());
		Parcelable iconResource = Intent.ShortcutIconResource.fromContext( this,  R.drawable.ic_launcher);
		Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");    
		intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name)); 
		intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, iconResource);
		intent.putExtra("duplicate", false); // �ߺ� ���� ����
		sendBroadcast(intent);

	}
	
	public void deleteShortcutAtLuncher(){
		// com.android.launcher.action.INSTALL_SHORTCUT ���� �߰��� Shortcut ����
		
		Intent shortcutIntent = new Intent(Intent.ACTION_MAIN);
		shortcutIntent.setClassName(this, this.getClass().getName());
		Parcelable iconResource = Intent.ShortcutIconResource.fromContext( this,  R.drawable.ic_launcher);
		Intent intent = new Intent("com.android.launcher.action.UNINSTALL_SHORTCUT");
		intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name)); 
		intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, iconResource);
		sendBroadcast(intent);
	
		// Laucher�� ���� ��ϵ� ShortCut ����
		shortcutIntent = new Intent(Intent.ACTION_MAIN);
		shortcutIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		shortcutIntent.setClassName(this, this.getClass().getName());
		iconResource = Intent.ShortcutIconResource.fromContext( this,  R.drawable.ic_launcher);
		intent = new Intent("com.android.launcher.action.UNINSTALL_SHORTCUT");    
		intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name)); 
		intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, iconResource);
		sendBroadcast(intent);
		
	}

	@Override
	public void onClosedInterstitialAd(CaulyInterstitialAd arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFailedToReceiveInterstitialAd(CaulyInterstitialAd arg0,
			int arg1, String arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onReceiveInterstitialAd(CaulyInterstitialAd ad, boolean isChargeableAd) {
		// ���� ���� ������ ��� ȣ���.
		// ���ŵ� ������ ���� ������ ��� isChargeableAd ���� false ��.
		if (isChargeableAd == false) {
			Log.d("CaulyExample", "free interstitial AD received.");
		}
		else {
			Log.d("CaulyExample", "normal interstitial AD received.");
		}

		// ���� ����
		ad.show();

	}
}
