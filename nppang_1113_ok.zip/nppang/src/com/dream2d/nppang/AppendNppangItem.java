package com.dream2d.nppang;

import com.dream2d.nppang.R;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class AppendNppangItem extends Activity {
	
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;
	
	Button mButtonAppendNppangItemOk;
	Button mButtonAppendNppangItemCancel;
	
	
	
	EditText mEditTextInputNnppangItem;
	//EditText mEditTextAccountBank;
	
	SQLiteDatabase myDB;
	ContentValues contentvalue;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.append_nppang_item);
		
		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();
		
		mButtonAppendNppangItemOk = (Button) findViewById(R.id.button_append_nppang_item_ok);
		mButtonAppendNppangItemCancel = (Button) findViewById(R.id.button_append_nppang_item_cancel);		
		
		mEditTextInputNnppangItem = (EditText) findViewById(R.id.edit_text_input_nppang_item);
		//mEditTextAccountBank = (EditText) findViewById(R.id.edit_text_account_bank);
		
		mButtonAppendNppangItemOk.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				DBAdapter.appendNppangItem(mEditTextInputNnppangItem.getText().toString());
				Toast.makeText(AppendNppangItem.this, "�߰� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
				
				AppendNppangItem.this.setResult(RESULT_OK);
				AppendNppangItem.this.finish();
			}
		});
		mButtonAppendNppangItemCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				AppendNppangItem.this.finish();
			}
		});

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}	
	
}
