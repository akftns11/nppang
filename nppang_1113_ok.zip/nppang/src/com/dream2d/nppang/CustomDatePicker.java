package com.dream2d.nppang;


import java.util.Calendar;


import com.dream2d.nppang.R;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;


public class CustomDatePicker extends Activity  {
	private int mDeviceScreenWidth;
	private int mDeviceScreenHeight;

	ImageButton mImageButtonLastMonth;
	ImageButton mImageButtonNextMonth;
	private Calendar mCalendarToday = Calendar.getInstance();
	private int PAGER_COUNT=3;
	int mSelectedDay=0;
	int mSelectedMonth=0;
	int mSelectedYear=0;
	int mCurrentYear;
	int mCurrentMonth;

//	View mViewCalendar[] = new View[PAGER_COUNT];


	public ViewPager mPager;
	//private int mPrevPosition=-1;						//������ ���õǾ��� ������ ��


	private TextView mPreviousSelectedDate;
	//	private RelativeLayout mMonthIndicator;
	public int mPreviousPosition=-1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.date_picker);

		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		mDeviceScreenWidth = display.getWidth();
		mDeviceScreenHeight = display.getHeight();

		mCurrentYear = mCalendarToday.get(Calendar.YEAR);
		mCurrentMonth = mCalendarToday.get(Calendar.MONTH)+1;

		mPager = (ViewPager) findViewById(R.id.pager);
		mPager.setAdapter(new PagerAdapterClass(this));

		//makeCalendarView();

		mPager.setCurrentItem(Integer.MAX_VALUE/2 - (Integer.MAX_VALUE/2)%PAGER_COUNT + 1);
		mPreviousPosition = Integer.MAX_VALUE/2 - (Integer.MAX_VALUE/2)%PAGER_COUNT + 1;
		
		((TextView) findViewById(R.id.month_and_year)).setText(mCurrentYear + "�� " + mCurrentMonth + "��");

		
		mPager.setOnPageChangeListener(new OnPageChangeListener() {	//�������� ����Ǹ�, gallery�� listview�� onItemSelectedListener�� ���
			@Override public void onPageSelected(int position) {
				
				// ���޷� �̵�
				if(position%PAGER_COUNT == mPreviousPosition%PAGER_COUNT -1 || (mPreviousPosition%PAGER_COUNT ==0 && position%PAGER_COUNT == PAGER_COUNT-1)){
					if(mCurrentMonth == 1){
						mCurrentYear--;
						mCurrentMonth = 12;
					}
					else{
						mCurrentMonth--;
					}					
				}
				// �����޷� �̵�
				else if(position%PAGER_COUNT == mPreviousPosition%PAGER_COUNT+1 || (position%PAGER_COUNT==0 && mPreviousPosition%PAGER_COUNT == PAGER_COUNT-1)){
					if(mCurrentMonth == 12){
						mCurrentYear++;
						mCurrentMonth = 1;
					}
					else{
						mCurrentMonth++;
					}					
				}
				mPreviousPosition = position;
				((TextView) findViewById(R.id.month_and_year)).setText(mCurrentYear + "�� " + (mCurrentMonth) + "��");
			}

			@Override public void onPageScrolled(int position, float positionOffest, int positionOffsetPixels) {}
			@Override public void onPageScrollStateChanged(int state) {}
		});



		mImageButtonLastMonth = (ImageButton) findViewById(R.id.last_month);
		mImageButtonNextMonth = (ImageButton) findViewById(R.id.next_month);
		mImageButtonLastMonth.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if(mCurrentMonth == 1){
					mCurrentYear--;
					mCurrentMonth = PAGER_COUNT;
	//				makeCalendarView();	            	
					mPager.setCurrentItem(mCurrentMonth,true);
				}
				else{
					mCurrentMonth--;
					mPager.setCurrentItem(mCurrentMonth,true);
				}				
			}
		});


		mImageButtonNextMonth.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if(mCurrentMonth == PAGER_COUNT){
					mCurrentYear++;
					mCurrentMonth = 1;
//					makeCalendarView();
					mPager.setCurrentItem(mCurrentMonth,true);
				}
				else{
					mCurrentMonth++;
					mPager.setCurrentItem(mCurrentMonth,true);

				}
			}
		});



	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {			
			int x = (int)event.getX();
			int y = (int)event.getY();

			Bitmap bitmapScreen = Bitmap.createBitmap(mDeviceScreenWidth, mDeviceScreenHeight, Bitmap.Config.ARGB_8888);

			if(x < 0 || y < 0)
				return false;

			int ARGB = bitmapScreen.getPixel(x, y);

			if(Color.alpha(ARGB) == 0) {
				finish();
			}

			return true;
		}
		return false;
	}


	private View fillCalendarView(int year, int month) {
		//calendar.removeAllViews();
		TableLayout calendar = new TableLayout(this);
	//	calendar.setGravity(Gravity.CENTER);	// yunsun
		calendar.setStretchAllColumns(true);


		int firstDayOfWeek, lastMonthDay, nextMonthDay=1;

		int day_count = day_count_of_month(year, month);
		firstDayOfWeek = day_of_week(year, month);
		if(month == 1){
			lastMonthDay = day_count_of_month(year-1, PAGER_COUNT) - firstDayOfWeek +1;	
		}
		else{
			lastMonthDay = day_count_of_month(year, month-1) - firstDayOfWeek +1;
		}

		TableRow.LayoutParams lp = new TableRow.LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		//lp.weight = 1;

		TableRow mTableRowDayOfTheWeek = new TableRow(this);


		TextView mTextViewDayOfTheWeek;
		
		String[] mDayOfTheWeek= getResources().getStringArray(R.array.day_of_the_week);
		for(int i=0; i<7; i++){
			mTextViewDayOfTheWeek= new TextView(this);
			mTextViewDayOfTheWeek.setLayoutParams(lp);
			mTextViewDayOfTheWeek.setBackgroundColor(Color.parseColor("#111111"));
			mTextViewDayOfTheWeek.setGravity(Gravity.CENTER);
			mTextViewDayOfTheWeek.setTextColor(Color.parseColor("#ffffff"));
			mTextViewDayOfTheWeek.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
			
			mTextViewDayOfTheWeek.setText(mDayOfTheWeek[i]);

			mTextViewDayOfTheWeek.setPadding(0, 5, 0, 5);

			mTableRowDayOfTheWeek.addView(mTextViewDayOfTheWeek);	
		}

		calendar.addView(mTableRowDayOfTheWeek);

		TableRow week = new TableRow(this);
		TextView date;



		// initialize the day counter to 1, it will be used to display the dates of the month
		int day = 1;
		int week_count = (firstDayOfWeek + day_count) / 7;
		if((firstDayOfWeek + day_count)%7 != 0){
			week_count++;
		}
		
		for (int i = 0; i < week_count; i++) {
		
			week = new TableRow(this);
			// this loop is used to fill out the days in the i-th row in the calendar
			for (int j = 0; j < 7; j++) {
				date = new TextView(this);
				date.setLayoutParams(lp);
				date.setBackgroundColor(Color.parseColor("#333333"));
				date.setGravity(Gravity.CENTER);
				date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
				date.setTextColor(Color.parseColor("#535353"));
				date.setTypeface(null, Typeface.BOLD);

				// last month
				if (j < firstDayOfWeek && day == 1)
					date.setText(String.valueOf(lastMonthDay++));
				// next month
				else if (day > day_count) {
					date.setText(String.valueOf(nextMonthDay++));
				} else // this month
				{
					date.setBackgroundResource(R.drawable.background_normal_days);
					//mCurrentMonth.set(Calendar.DAY_OF_MONTH, day);
					date.setOnClickListener(dayClickedListener);
					date.setOnLongClickListener(dayLongClickedListener);

					// today
					if (day == mCalendarToday.get(Calendar.DAY_OF_MONTH) && month == mCalendarToday.get(Calendar.MONTH)+1
							&& year == mCalendarToday.get(Calendar.YEAR)) {
						//mPreviousSelectedDate = date;
						date.setBackgroundResource(R.drawable.background_today);
					}
					// date selected
					else if (mSelectedMonth == month && mSelectedDay == day) {
						mPreviousSelectedDate = date;
						date.setBackgroundResource(R.drawable.background_day_selected);
					}

					date.setText(String.valueOf(day++));

					if (j == 0) // Sunday
						date.setTextColor(Color.parseColor("#D73C10"));
					else if (j == 6) // Saturday
						date.setTextColor(Color.parseColor("#009EF7"));
					else
						date.setTextColor(Color.WHITE);
				}
				date.setPadding(0, 8, 0, 8);
				week.addView(date);
			}
			calendar.addView(week);
		}

		return calendar;
	}




	private OnClickListener dayClickedListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			int selectedDay = Integer.parseInt(((TextView) view).getText().toString());		
			int priviousSelectedDay=0;
			final int selectday = Integer.parseInt(((TextView) view).getText().toString());
			if(mPreviousSelectedDate == view){
				AlertDialog.Builder alt_bld = new AlertDialog.Builder(CustomDatePicker.this);
				alt_bld.setMessage(mCurrentYear + "�� " + mCurrentMonth + "�� " + ((TextView) view).getText().toString() + "���� �����Ͻðڽ��ϱ�?"
						).setCancelable(
								false).setPositiveButton("Yes",
										new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int id) {
										Intent intent = new Intent();										
										Bundle extra = new Bundle();										
										extra.putInt("year", mCurrentYear);
										intent.putExtras(extra);
										extra = new Bundle();									
										extra.putInt("month", mCurrentMonth);
										intent.putExtras(extra);
										extra = new Bundle();									
										extra.putInt("day", selectday);
										intent.putExtras(extra);
										
										CustomDatePicker.this.setResult(RESULT_OK, intent);
										CustomDatePicker.this.finish();
									}
								}).setNegativeButton("No",
										new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int id) {
										// Action for 'NO' Button
										dialog.cancel();
									}
								});
				AlertDialog alert = alt_bld.create();
				// Title for AlertDialog
				alert.setTitle("Title");
				// Icon for AlertDialog
				alert.setIcon(R.drawable.ic_launcher);
				alert.show();
				return;
			}
			if(mPreviousSelectedDate != null){
				priviousSelectedDay = Integer.parseInt(((TextView) mPreviousSelectedDate).getText().toString());
			}
			mSelectedDay = selectedDay;
			view.setBackgroundResource(R.drawable.background_day_selected);
			view.setPadding(0, 8, 0, 8);
			if (mPreviousSelectedDate != null) {
				if(priviousSelectedDay == mCalendarToday.get(Calendar.DAY_OF_MONTH) && mCurrentMonth == mCalendarToday.get(Calendar.MONTH)+1
						&& mCurrentYear == mCalendarToday.get(Calendar.YEAR)){
					mPreviousSelectedDate.setBackgroundResource(R.drawable.background_today);
				}
				else{
					mPreviousSelectedDate.setBackgroundResource(R.drawable.background_normal_days);
				}
				mPreviousSelectedDate.setPadding(0, 8, 0, 8);
			}
			mPreviousSelectedDate = (TextView) view;

		}
	};

	private OnLongClickListener dayLongClickedListener = new OnLongClickListener() {

		@Override
		public boolean onLongClick(View view) {
			final int selectday = Integer.parseInt(((TextView) view).getText().toString());
			AlertDialog.Builder alt_bld = new AlertDialog.Builder(CustomDatePicker.this);
			alt_bld.setMessage(mCurrentYear + "�� " + mCurrentMonth + "�� " + selectday + "���� �����Ͻðڽ��ϱ�?"
					).setCancelable(
							false).setPositiveButton("Yes",
									new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int id) {
									Intent intent = new Intent(); 
									Bundle extra = new Bundle();									
									extra.putInt("year", mCurrentYear);
									intent.putExtras(extra);
									extra = new Bundle();									
									extra.putInt("month", mCurrentMonth);
									intent.putExtras(extra);
									extra = new Bundle();									
									extra.putInt("day", selectday);
									intent.putExtras(extra);
									CustomDatePicker.this.setResult(RESULT_OK, intent);
									CustomDatePicker.this.finish();
									
								}
							}).setNegativeButton("No",
									new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int id) {
									// Action for 'NO' Button
									dialog.cancel();
								}
							});
			AlertDialog alert = alt_bld.create();
			// Title for AlertDialog
			alert.setTitle("Title");
			// Icon for AlertDialog
			alert.setIcon(R.drawable.ic_launcher);
			alert.show();
			return false;
		}
	};

	int day_of_week(int year,int month) //�� �ϼ��� ���ϴ� �Լ�(�ش� �� 1���� ������������ �˱�����)
	{
		int temp = 0; //�ӽ÷� ��꿡 ����� ����
		int i; //for ������ ����� ����

		for(i=1;i<year;i++) { //�⵵�� �ϼ�
			if((i%4 == 0) && (i%100 != 0) || (i%400 == 0)) {
				temp += 366;
			} else {
				temp += 365;    
			}
		}
		for(i=1;i<month;i++) { //�� �� �ϼ�
			if ( i==2 ) { // 2���ϰ�� ���� �˻�
				if((year%4==0) && (year%100 != 0) || (year%400 == 0))
					temp += 29;
				else
					temp += 28;
			}
			switch (i) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				temp += 31; //�Ѵ��� 31���� ���
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				temp += 30; //�Ѵ��� 30���� ���
				break;
			}
		}

		temp = temp + 1; //���������� �ϼ��� ���� �� �� ���� ���Ѵ�

		return temp % 7; //1=��,2=ȭ...6=��,0=��
	}

	int day_count_of_month(int year, int month){
		int temp=0; //�ش� ���� �� �ϼ�
		switch (month) { //�Ѵ��� �ϼ��� ���Ѵ�
		case 1:       case 3:       case 5:       case 7:       case 8:       case 10:       case 12:
			temp = 31; //�Ѵ��� 31���� ���
			break;
		case 4:       case 6:       case 9:       case 11:
			temp = 30; //�Ѵ��� 30���� ���
			break;
		case 2: //2���� ���
			if((year%4==0) && (year%100 != 0) || (year%400 == 0))
				temp = 29;
			else
				temp = 28;
		}
		return temp;
	}

	private class PagerAdapterClass extends PagerAdapter{
		private LayoutInflater mInflater;    
		//boolean initFlig = false;
		public PagerAdapterClass(Context c){
			super();
			mInflater = LayoutInflater.from(c);
		}

		@Override
		public int getCount() {
			return Integer.MAX_VALUE;
		}       

		@Override
		public Object instantiateItem(View pager, int position) {
			View v=null;
			if(position < mPreviousPosition){
				if(mCurrentMonth == 1){
					v = fillCalendarView(mCurrentYear-1, 12);;
				}
				else{
					v = fillCalendarView(mCurrentYear, mCurrentMonth-1);;
				}
			}
			else if(position == mPreviousPosition){
				v = fillCalendarView(mCurrentYear, mCurrentMonth);;
			}
			else if(position > mPreviousPosition){
				if(mCurrentMonth == 12){
					v = fillCalendarView(mCurrentYear+1, 1);;
				}
				else{
					v = fillCalendarView(mCurrentYear, mCurrentMonth+1);;
				}				
			}
			
			((ViewPager)pager).addView(v, 0);
			return v; 
		}

		@Override
		public void destroyItem(View pager, int position, Object view) {    
			((ViewPager)pager).removeView((View)view);
		}

		@Override
		public boolean isViewFromObject(View pager, Object obj) {
			return pager == obj; 
		}

		@Override public void restoreState(Parcelable arg0, ClassLoader arg1) {}
		@Override public Parcelable saveState() { return null; }
		@Override public void startUpdate(View arg0) {}
		@Override public void finishUpdate(View arg0) {}
	}
}