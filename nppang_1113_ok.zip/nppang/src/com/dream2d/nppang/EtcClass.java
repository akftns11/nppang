package com.dream2d.nppang;

public class EtcClass {
	
	public static final int SEND_NPPANG = 0;
	public static final int SENDED_LIST = 1;
	public static final int ABOUT_US = 2;
	public static final int PAGE_COUNT = 3;
	
	
	
	// DB ���� String
	// DB ���� ���� �̸�
	public static final String DB_NAME = "nppang.db";
	
	// Account DB
	public static final String DB_TABLE_ACCOUNT = "account";	
	public static final String ACCOUNT_PRIMARY_KEY = "account_primary_key";
	public static final String ACCOUNT_BANK = "account_bank";
	public static final String ACCOUNT_NUMBER = "account_number";
	public static final String ACCOUNT_OWNER = "account_owner";
	// N�� Item DB
	public static final String DB_TABLE_NPPANG_ITEM = "nppang_item";
	public static final String NPPANG_ITEM_PRIMARY_KEY = "nppang_item_primary_key";
	public static final String NPPANG_ITEM = "nppang_item";	
	// ���������� ������ �� DB 
	public static final String DB_TABLE_LAST_SELECTED = "last_selected";
	public static final String LAST_SELECTED_PRIMARY_KEY = "last_selected_primary_key";
	public static final String LAST_SELECTED_NPPANG_ITEM = "last_selected_nppang_item";
	public static final String LAST_SELECTED_ACCOUNT_BANK = "last_selected_account_bank";
	public static final String LAST_SELECTED_ACCOUNT_NUMBER = "last_selected_account_number";
	public static final String LAST_SELECTED_ACCOUNT_OWNER = "last_selected_account_owner";
	// ���� ��� DB
	public static final String DB_TABLE_SENT_NPPANG_LIST = "sent_nppang_list";
	public static final String SENT_NPPANG_LIST_PRIMARY_KEY = "sent_nppang_list_primary_key";
	public static final String SENT_NPPANG_LIST_DATE = "sent_nppang_list_date";
	public static final String SENT_NPPANG_LIST_MESSAGE = "sent_nppang_list_message";
	public static final String SENT_NPPANG_LIST_MONEY = "sent_nppang_list_money";
	public static final String SENT_NPPANG_LIST_N = "sent_nppang_list_n";
	public static final String SENT_NPPANG_LIST_BANK = "sent_nppang_list_bank";
	public static final String SENT_NPPANG_LIST_ACCOUNT_NUMBER = "sent_nppang_list_account_number";
	public static final String SENT_NPPANG_LIST_ACCOUNT_OWNER = "sent_nppang_list_account_owner";
	public static final String SENT_NPPANG_LIST_NPPANG_ITEM = "sent_nppang_list_nppang_item";
	// �ʱⰪ
	public static final String INVALID_VALUE = "-1";
	
	// ��Ÿ String
	public static final String YEAR = "year";
	public static final String MONTH = "month";
	public static final String DAY = "day";
	public static final String NPPANG_PERSON_COUNT = "nppang_person_count";
	public static final String NPPANG_TOTAL_MONEY = "nppang_total_money";
	
	// �ѹ��� �ҷ����� SMS ����
	public static final int SMS_LOAD_COUNT = 20;
	// �ѹ��� Set �ϴ� N���� ����
	public static final int NPPANG_PERSON_LOAD_COUNT = 10;
	// SMS �� �ҷ����� Deleay time
	public static final int POST_DELEAY_TIME_FOR_LOAD_SMS_LOAD = 300;
	// N���� ������ �����ϴµ� ���Ǵ� Deleay time
	public static final int POST_DELEAY_TIME_FOR_LOAD_NPPANG_PERSON_LOAD_COUNT =100;
	// back key �� �ι� ���� Activity �� �����Ҷ� ����ϴ� Deleay time
	public static final int BACK_DELEAY_TIME_FOR_FINISH_ACTIVITY = 3000;
	
	// Activity�� �޽���
	public static final int ACTIVITY_REQUEST_CODE_FOR_DATE_PICKER = 1;
	public static final int ACTIVITY_REQUEST_CODE_FOR_LOAD_ACCOUNT = 2;
	public static final int ACTIVITY_REQUEST_CODE_FOR_APPEND_ACCOUNT = 3;
	public static final int ACTIVITY_REQUEST_CODE_FOR_SELECT_BANK = 4;
	public static final int ACTIVITY_REQUEST_CODE_FOR_NPPANG_PERSON_COUNT = 5;
	public static final int ACTIVITY_REQUEST_CODE_FOR_LOAD_NPPANG_TOTAL_MONEY = 6;
	public static final int ACTIVITY_REQUEST_CODE_FOR_SEND_NPPANG = 7;
	public static final int ACTIVITY_REQUEST_CODE_FOR_SELECT_NPPANG_ITEM = 8;
	public static final int ACTIVITY_REQUEST_CODE_FOR_APPEND_NPPANG_ITEM = 9;
}
