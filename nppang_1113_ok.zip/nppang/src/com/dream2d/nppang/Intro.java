package com.dream2d.nppang;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Window;

public class Intro extends Activity{
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.intro);
		Initialize();
		
	}
	void Initialize(){
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg){
				finish();	// intro activity ����
			}
		};
		handler.sendEmptyMessageDelayed(0, 1500); // 3�� �� ���� ��Ŵ
	}
	
	
}
