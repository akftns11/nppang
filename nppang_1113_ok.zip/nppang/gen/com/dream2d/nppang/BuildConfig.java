/** Automatically generated file. DO NOT MODIFY */
package com.dream2d.nppang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}